import { useParams } from 'react-router-dom';

// Simulación de datos de productos
const productData = {
  1: { name: "Producto 1", description: "Descripción del Producto 1", price: "$10" },
  2: { name: "Producto 2", description: "Descripción del Producto 2", price: "$20" },
  3: { name: "Producto 3", description: "Descripción del Producto 3", price: "$30" },
};

function ProductDetail() {
  const { id } = useParams(); // Obtiene el parámetro id de la URL
  const product = productData[id]; // Busca el producto basado en el id

  // Si el producto no existe, muestra un mensaje de error
  if (!product) {
    return <h2>Producto no encontrado</h2>;
  }

  return (
    <div>
      <h2>{product.name}</h2>
      <p>{product.description}</p>
      <p>Precio: {product.price}</p>
    </div>
  );
}

export default ProductDetail;
