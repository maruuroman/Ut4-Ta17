function Contact() {
    return (
      <div>
        <h2>Contact Page</h2>
        <p>Get in touch with us through this Contact page.</p>
      </div>
    );
  }
  
  export default Contact;
  