import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './Components/Home';
import About from "./Components/About";
import Contact from './Components/Contacts';
import ProductDetail from './Components/ProductDetail'; // Importar el componente


function App() {
  return (
    <Router>
      {/*enlaces que apuntan a las distintas rutas*/}
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
          <li>
            <Link to="/product/1">Producto 1</Link> {/* Enlace directo a Producto 1 */}
          </li>
          <li>
            <Link to="/product/2">Producto 2</Link> {/* Enlace directo a Producto 2 */}
          </li>
          <li>
            <Link to="/product/3">Producto 3</Link> {/* Enlace directo a Producto 3 */}
          </li>
        </ul>
      </nav>
      
      {/*cada ruta usa un componente específico para renderizar el contenido*/}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/product/:id" element={<ProductDetail />} /> {/* Ruta dinámica */}
      </Routes>
    </Router>
  );
}

export default App;
